// Account: fullname, email, username, phone, role, isActive, status, url_avatar, isFirst
// Product: barcode, name, import_price, retail_price, category, creation_date, url_image
// Cart: employeeName, productBarcode, productName, price, quantity, totalPrice
// Order: employeeName, customerPhone, totalQuantity, totalPrice, received, refunds, creation_date
// Customer: name, phone, address
// DetailsOrder: orderId, productBarcode, productName, price, quantity, totalPrice